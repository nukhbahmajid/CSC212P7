package edu.smith.cs.csc212.adtr.errors;

/**
 * I've defined this class for all starter code methods you need to implement.
 * @author jfoley
 */
@SuppressWarnings("serial")
public class TODOErr extends RuntimeException {
	public TODOErr() {
		super("TODO-Error");
	}
}
